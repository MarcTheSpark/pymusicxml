# pymusicxml

_pymusicxml_ is a simple python library for exporting (and perhaps in the future, importing) MusicXML. It is part of [scamp](https://github.com/MarcTheSpark/scamp/), a Suite for Composing Algorithmic Music in Python.

See the examples folder for an example of an explicitly created and exported score, as well as an algorithmically created and exported score.

